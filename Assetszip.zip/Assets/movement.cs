using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement : MonoBehaviour
{
    public float speed;
    Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddRelativeForce(transform.forward * speed / 4);
        }
        if (Input.GetKey(KeyCode.S))
        {
            rb.AddForce(Vector3.forward * -speed / 2);
        }
    }
    void FixedUpdate()
    {
        float turn = Input.GetAxis("Horizontal") * -50 * Time.deltaTime;
        rb.AddTorque(transform.up * turn);
        rb.velocity = new Vector3(turn / 2 * -50, rb.velocity.y, rb.velocity.z);
    }

}